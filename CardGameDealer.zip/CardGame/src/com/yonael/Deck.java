package com.yonael;

import java.util.ArrayList;
import java.util.Collections;

public class Deck {
    private ArrayList<Card> deck;

    /**
     * populates the deck with all cards
     */
    public Deck() {
        deck  = new ArrayList<>();
        shuffle();
    }

    public Card deal() {
        if(!deck.isEmpty()) {
            Card card = deck.get(deck.size() - 1); //deals whats on top
            deck.remove(card);
            return card;
        }
        shuffle();
        Card card = deck.get(deck.size() - 1);
        deck.remove(card);
        return card;
    }

    /**
     * helper method to populate and reshuffle the deck
     */
    private void shuffle() {
        for(Ranks r: Ranks.values()) {
            for (Suits s: Suits.values()) {
                deck.add(new Card(r, s));
            }
        }
        Collections.shuffle(deck);
    }
}
