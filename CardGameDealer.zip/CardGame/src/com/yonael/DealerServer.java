package com.yonael;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DealerServer extends Thread{

    private final int port; // The port that the addOne service will run on
    private DealerProtocol protocol; //The thread that manages the conversation between the server and a client
    private ServerSocket server; // The socket that listens for connections requests

    public DealerServer(int port) {
        this.port = port;
        try {
            server = new ServerSocket(port);
        } catch (IOException e) {
            Logger.getLogger(DealerServer.class.getName()).log(Level.SEVERE, "Dealer server failed to connect", e);
        }
    }

    @Override
    public void run(){
        //Check that the ServerScoket was created correctly and is running
        System.out.println("Server running");
        if ( server == null || !server.isBound()){
            System.out.println("Server not bound");
            System.exit(port);
        }

        try {
            //waits for a client request to connect This does the work
            //of creating the and starting the protocol
            Socket client = server.accept();
            protocol = new DealerProtocol(client);
            System.out.println("Connection !");
            protocol.start();
        } catch (IOException ex) {
            Logger.getLogger(DealerProtocol.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Failed on accept " + ex.getMessage() + " " + ex.toString());
        }

    }
}
