package com.yonael;

import java.io.*;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DealerProtocol extends Thread {
    protected Socket client; // the client scocket allows the protocol to communicate with the client
    protected OutputStream toClient; // This will be attached to the client's InputStream
    protected InputStream fromClient; // This will be attached to the client's OutputStream

    public DealerProtocol(Socket client) {
        System.out.println("Protocol running");
        try {
            this.client = client;
            toClient = client.getOutputStream();
            fromClient = client.getInputStream();
        } catch (IOException e) {
            Logger.getLogger(DealerProtocol.class.getName()).log(Level.SEVERE, "Protocol failed", e);
        }
    }

    /**
     * The run method manages the server to client communication
     */
    @Override
    public void run() {
        //Ths block wraps the client's input and output streams to object input and output streams
        ObjectInputStream objFromClient = null;
        ObjectOutputStream objToClient = null;

        try {
            objFromClient = new ObjectInputStream(fromClient);
            objToClient = new ObjectOutputStream(toClient);
        } catch (IOException e) {
            Logger.getLogger(DealerProtocol.class.getName()).log(Level.SEVERE, "object streams connection failed", e);
        }

        // Check to see if the connection was successful
        if (objFromClient == null || objToClient == null) {
            return;
        }
        Deck deck = new Deck();

        while(true) {
            try {
                objFromClient.readInt();
                objToClient.writeObject(deck.deal());
                objToClient.flush();
            } catch (IOException e) {
                Logger.getLogger(DealerProtocol.class.getName()).log(Level.SEVERE, "Card was not dealt", e);
            }
        }
    }
}
