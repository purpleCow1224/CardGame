package com.yonael;

/**
 * @author Yonael Dawit
 */
public class Main {

    public static void main(String[] args) {
        DealerServer server = new DealerServer(4999);
        server.start();
    }
}
