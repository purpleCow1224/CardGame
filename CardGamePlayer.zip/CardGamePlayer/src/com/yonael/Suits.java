package com.yonael;

public enum Suits {

    DIAMONDS(1),
    CLUBS(2),
    HEARTS(3),
    SPADES(4);

    private int value;

    Suits(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
