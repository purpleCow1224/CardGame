package com.yonael;

import java.util.Collections;
import java.util.Random;
import java.util.Stack;

public class Player {
    private String name;
    private int score;
    private Stack<Card> hand;
    private Random random = new Random();

    public Player(String name) {
        this.name = name;
        hand = new Stack<>();
        score = 0;
    }

    public String getName() {
        return name;
    }

    public Stack<Card> getHand() {
        return hand;
    }

    /**
     * Simple method to add card in players hand
     * @param card
     */
    public void addCard(Card card) {
        hand.push(card);
    }

    /**
     * @return A random card from hand
     */
    public Card peekCard () {
        return hand.peek(); //get the card on top
    }

    public int getScore() {
        return score;
    }

    public void addScore(int points) {
        score += points;
    }

    public void shuffle() {
        Collections.shuffle(hand);
    }

    @Override
    public String toString() {
        String s = name + ": ";
        for (Card c: hand) {
          s += c.toString() + "\n";
        }
        return s;
    }
}
