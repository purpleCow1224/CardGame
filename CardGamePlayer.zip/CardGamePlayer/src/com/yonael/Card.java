package com.yonael;

import java.io.Serializable;

public class Card implements Serializable {
    private final Ranks ranks;
    private final Suits suits;

    public Card(Ranks ranks, Suits suits) {
        this.ranks = ranks;
        this.suits = suits;
    }

    public Ranks getRank() {
        return ranks;
    }

    public int getRankValue() {
        return ranks.getValue();
    }

    public Suits getSuit() {
        return suits;
    }

    public int getSuitValue() {
        return suits.getValue();
    }

    @Override
    public String toString() {
        return ranks + " of " + suits;
    }
}
