package com.yonael;


import java.util.ArrayList;
import java.util.List;

public class Table {
    private List<Player> table;

    /**
     * Constructor without the number of players
     */
    public Table() {
        table = new ArrayList<>();
    }

    /**
     * @return List of players
     */
    public List<Player> getTable() {
        return table;
    }

    /**
     * Adds player to the table
     * @param player
     */
    public void addPlayer(Player player) {
        table.add(player);
    }


    /**
     * @return The names of each player
     */
    @Override
    public String toString() {
        String s = "Table{ ";
        for (Player p: table) {
            s += p.getName() + " , ";
        }
        return s;
    }
}
