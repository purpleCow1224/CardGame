package com.yonael;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

public class Game {
    Socket s = new Socket(InetAddress.getLoopbackAddress(), 4999);
    InputStream in = s.getInputStream();
    OutputStream out = s.getOutputStream();
    ObjectOutputStream objOut = new ObjectOutputStream(out);
    ObjectInputStream objIn = new ObjectInputStream(in);
    private int deckSize = 52;

    public Game() throws IOException {
    }

    /**
     * Plays the game and adds the score
     * Sets up the game up and plays till winner is found
     * score
     * @param table
     */
    public void play(Table table) throws IOException, ClassNotFoundException {
        setUpGame(table);
        while (highScore(table) <= 20) {
            resetGame(table);
            Player winner = HighCard(table);

            objOut.writeInt(deckSize--);
            objOut.flush();
            Card card = (Card) objIn.readObject();
            winner.addCard(card);

            for (Player player : table.getTable()) {
                if (player.equals(winner)) { //makes sure to not compare the winner to itself
                    continue;
                }

                if (compareRank(winner, player).equals(winner)) {
                    winner.addScore(1);
                    player.addScore(-2);
                } else if (compareRank(winner, player).equals(player)) {
                    winner.addScore(-1);
                    player.addScore(3);
                } else {
                    if (compareSuit(winner, player).equals(winner)) {
                        winner.addScore(1);
                        player.addScore(-2);
                    } else {
                        winner.addScore(-1);
                        player.addScore(3);
                    }
                }
            }

            //prints players scoreboard
            for (Player player : table.getTable()) {
                System.out.println(player.getName() + ": " + player.getScore());
            }
            System.out.println();
        }
    }

    /**
     * Gives 3 cards round robin style to each player
     * on the table
     * @param table
     */
    private void setUpGame(Table table) throws IOException, ClassNotFoundException {
        for (int i = 0; i < 3; i++) {
            for (Player player: table.getTable()) {
                objOut.writeInt(deckSize--);
                objOut.flush();
                player.addCard((Card) objIn.readObject());
            }
        }

        for (Player player: table.getTable()) {
            System.out.println(player.toString());
        }
    }

    /**
     * Checks each player's rank and suit and gets the player with the
     * highest value.
     *
     * @return Player with the highest card
     */
    private Player HighCard(Table table) {
        Player currChampion = table.getTable().get(0);
        for (int i = 1; i < table.getTable().size(); i++) {
            Player current = table.getTable().get(i);
            current.shuffle(); //randomize cards
            if (compareRank(currChampion, current).equals(currChampion)) {
                continue;
            } else if (compareRank(currChampion, current).equals(current)) {
                currChampion = table.getTable().get(i);
            } else {
                currChampion = compareSuit(currChampion, current);
            }
        }
        return currChampion;
    }


    /**
     * Compares the rank of player 1 and player 2
     * @param p1  Player 1
     * @param p2 Player 1
     * @return Player with the higher rank
     */
    private Player compareRank(Player p1, Player p2) {
        if (p1.peekCard().getRankValue() > p2.peekCard().getRankValue()) {
            return p1;
        }
        return p2;
    }

    /**
     * Compares the suit of player 1 and player 2
     * @param p1  Player 1
     * @param p2 Player 1
     * @return Player with the higher rank
     */
    private Player compareSuit(Player p1, Player p2) {
        if (p1.peekCard().getSuitValue() > p2.peekCard().getSuitValue()) {
            return p1;
        }
        return p2;
    }

    /**
     * Gets the highest score from the table
     * @param table
     * @return
     */
    private int highScore(Table table) {
        int highScore= 0;
        for (Player player: table.getTable()) {
            highScore = Math.max(highScore, player.getScore());
        }
        return highScore;
    }

    private void resetGame(Table table) throws IOException, ClassNotFoundException {
        if (deckSize <= 0) {
            for (Player player: table.getTable()) {
                player.getHand().clear();
            }
            setUpGame(table);
        }
    }

}
