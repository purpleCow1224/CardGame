package com.yonael;

import java.io.IOException;
import java.net.InetAddress;

/**
 * @author Yonael Dawit
 */
public class Main {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Player player1 = new Player("Johnny");
        Player player2 = new Player("Naomi");
        Player player3 = new Player("Ayda");
        Player player4 = new Player("Yonael");

        Table yonaelsKids = new Table();
        yonaelsKids.addPlayer(player1);
        yonaelsKids.addPlayer(player2);
        yonaelsKids.addPlayer(player3);
        yonaelsKids.addPlayer(player4);

        Game game = new Game();
        game.play(yonaelsKids);
    }
}
